# Ansible

Install Ansible

amazon-linux-extras install ansible2

yum install ansible 


ansible-playbook vars.yml [ To run the playbook ]

ansible-galaxy init /etc/ansible/roles/create-user [ To create the role ]

ansible --version [ To verify ansible ]
